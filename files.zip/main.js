/**
 * LAB INTERFACE - Sistema de Microinterações
 * Baseado em princípios de Design Emocional e Ergonomia Cognitiva
 */

class LabInterface {
  constructor() {
    this.init();
  }

  init() {
    this.initScrollAnimations();
    this.initMouseTracking();
    this.initNavigation();
    this.initAcordeon();
    this.initFilters();
    this.initSmoothScroll();
    this.initHeaderScroll();
  }

  // ==========================================
  // ANIMAÇÕES DE SCROLL (Intersection Observer)
  // ==========================================

  initScrollAnimations() {
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    };

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add('animate');

          // Animação em cascata para elementos filhos
          const children = entry.target.querySelectorAll('[data-delay]');
          children.forEach(child => {
            const delay = child.dataset.delay || 0;
            setTimeout(() => {
              child.classList.add('animate');
            }, delay);
          });

          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);

    document.querySelectorAll('[data-animate]').forEach(el => {
      observer.observe(el);
    });
  }

  // ==========================================
  // TRACKING DE MOUSE (Efeitos de Glow)
  // ==========================================

  initMouseTracking() {
    // Efeito de brilho nos cards
    const cards = document.querySelectorAll('.disciplina-card, .conceito-card');

    cards.forEach(card => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;

        card.style.setProperty('--mouse-x', `${x}px`);
        card.style.setProperty('--mouse-y', `${y}px`);
      });
    });

    // Efeito no botão CTA
    const ctaButton = document.querySelector('.cta-button');
    if (ctaButton) {
      ctaButton.addEventListener('mousemove', (e) => {
        const rect = ctaButton.getBoundingClientRect();
        const x = ((e.clientX - rect.left) / rect.width) * 100;
        const y = ((e.clientY - rect.top) / rect.height) * 100;

        ctaButton.style.setProperty('--mouse-x', `${x}%`);
        ctaButton.style.setProperty('--mouse-y', `${y}%`);
      });
    }
  }

  // ==========================================
  // NAVEGAÇÃO
  // ==========================================

  initNavigation() {
    const menuToggle = document.querySelector('.menu-toggle');
    const navList = document.querySelector('.nav-list');
    const navLinks = document.querySelectorAll('.nav-link');

    // Toggle mobile
    if (menuToggle) {
      menuToggle.addEventListener('click', () => {
        const isExpanded = menuToggle.getAttribute('aria-expanded') === 'true';
        menuToggle.setAttribute('aria-expanded', !isExpanded);
        navList.classList.toggle('active');
        document.body.style.overflow = isExpanded ? '' : 'hidden';
      });
    }

    // Atualizar link ativo no scroll
    const sections = document.querySelectorAll('section[id]');

    window.addEventListener('scroll', () => {
      let current = '';
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (scrollY >= sectionTop - 200) {
          current = section.getAttribute('id');
        }
      });

      navLinks.forEach(link => {
        link.classList.remove('active');
        if (link.getAttribute('href') === `#${current}`) {
          link.classList.add('active');
        }
      });
    });

    // Efeito de hover nos links - revelação de texto
    navLinks.forEach(link => {
      link.addEventListener('mouseenter', function () {
        this.style.clipPath = 'inset(0 0 0 0)';
      });
    });
  }

  // ==========================================
  // ACORDEÃO (Conceitos)
  // ==========================================

  initAcordeon() {
    const headers = document.querySelectorAll('.conceito-header');

    headers.forEach(header => {
      header.addEventListener('click', () => {
        const isExpanded = header.getAttribute('aria-expanded') === 'true';
        const body = header.nextElementSibling;

        // Fechar outros (opcional - modo acordeão)
        headers.forEach(otherHeader => {
          if (otherHeader !== header) {
            otherHeader.setAttribute('aria-expanded', 'false');
            otherHeader.nextElementSibling.hidden = true;
          }
        });

        // Toggle atual
        header.setAttribute('aria-expanded', !isExpanded);
        body.hidden = isExpanded;

        // Animação suave de altura
        if (!isExpanded) {
          body.style.display = 'block';
          const height = body.scrollHeight;
          body.style.display = '';

          requestAnimationFrame(() => {
            body.style.maxHeight = height + 'px';
          });
        }
      });
    });
  }

  // ==========================================
  // FILTROS
  // ==========================================

  initFilters() {
    // Filtro de tags em conceitos
    const tags = document.querySelectorAll('.tag');
    const conceitos = document.querySelectorAll('.conceito-card');
    const countElement = document.getElementById('count');

    tags.forEach(tag => {
      tag.addEventListener('click', () => {
        // Atualizar estado ativo
        tags.forEach(t => t.classList.remove('active'));
        tag.classList.add('active');

        const filter = tag.dataset.filter;
        let visibleCount = 0;

        conceitos.forEach(conceito => {
          const category = conceito.dataset.category;

          if (filter === 'all' || category === filter) {
            conceito.style.display = 'block';
            conceito.style.animation = 'fadeUp 0.5s ease forwards';
            visibleCount++;
          } else {
            conceito.style.display = 'none';
          }
        });

        // Atualizar contador com animação
        this.animateNumber(countElement, parseInt(countElement.textContent), visibleCount);
      });
    });

    // Filtro de disciplinas
    const searchInput = document.querySelector('.search-input');
    const disciplinaCards = document.querySelectorAll('.disciplina-card');

    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();

        disciplinaCards.forEach(card => {
          const title = card.querySelector('.card-title').textContent.toLowerCase();
          const meta = card.querySelector('.card-meta').textContent.toLowerCase();

          if (title.includes(searchTerm) || meta.includes(searchTerm)) {
            card.style.display = 'block';
            card.style.opacity = '1';
          } else {
            card.style.opacity = '0';
            setTimeout(() => {
              card.style.display = 'none';
            }, 300);
          }
        });
      });
    }

    // Toggle de visualização (grid/lista)
    const viewBtns = document.querySelectorAll('.view-btn');
    const grid = document.getElementById('disciplinas-grid');

    viewBtns.forEach(btn => {
      btn.addEventListener('click', () => {
        viewBtns.forEach(b => b.classList.remove('active'));
        btn.classList.add('active');

        const view = btn.dataset.view;
        if (view === 'list') {
          grid.style.gridTemplateColumns = '1fr';
        } else {
          grid.style.gridTemplateColumns = 'repeat(auto-fill, minmax(350px, 1fr))';
        }
      });
    });

    // Filtro de projetos
    const projectPills = document.querySelectorAll('.pill');
    const projectCards = document.querySelectorAll('.projetos-grid .projeto-card');
    
    projectPills.forEach(pill => {
      pill.addEventListener('click', () => {
        projectPills.forEach(p => p.classList.remove('active'));
        pill.classList.add('active');

        const filter = pill.dataset.filter;

        projectCards.forEach(card => {
          const category = card.dataset.category;

          if (filter === 'all' || category === filter) {
            card.style.display = 'block';
            card.style.animation = 'fadeUp 0.5s ease forwards';
          } else {
            card.style.display = 'none';
          }
        });
        
        // Reset scroll pós-filtro para ver o 1o resultado
        const grid = document.querySelector('.projetos-grid');
        if(grid) grid.scrollTo({left: 0, behavior: 'smooth'});
      });
    });

    // Navegação Premium do Slider (Vanilla CSS Snap)
    const projetosGrid = document.querySelector('.projetos-grid');
    const navPrev = document.querySelector('.nav-prev');
    const navNext = document.querySelector('.nav-next');

    if (projetosGrid) {
      let isDown = false;
      let startX;
      let scrollLeft;

      // Mouse drag handlers
      projetosGrid.addEventListener('mousedown', (e) => {
        isDown = true;
        projetosGrid.classList.add('active');
        startX = e.pageX - projetosGrid.offsetLeft;
        scrollLeft = projetosGrid.scrollLeft;
        // Evita snapping travado no meio do arraste
        projetosGrid.style.scrollSnapType = 'none';
        projetosGrid.style.scrollBehavior = 'auto';
      });

      const finishDrag = () => {
        if (!isDown) return;
        isDown = false;
        projetosGrid.classList.remove('active');
        projetosGrid.style.scrollSnapType = 'x mandatory';
        projetosGrid.style.scrollBehavior = 'smooth';
      };

      projetosGrid.addEventListener('mouseleave', finishDrag);
      projetosGrid.addEventListener('mouseup', finishDrag);

      projetosGrid.addEventListener('mousemove', (e) => {
        if (!isDown) return;
        e.preventDefault();
        const x = e.pageX - projetosGrid.offsetLeft;
        const walk = (x - startX) * 1.5;
        projetosGrid.scrollLeft = scrollLeft - walk;
      });

      // Interação das Setas com Auto-Calculation
      if (navPrev && navNext) {
        const getScrollAmount = () => {
          const card = projetosGrid.querySelector('.projeto-card[style*="display: block"]') || projetosGrid.querySelector('.projeto-card');
          const gap = parseInt(window.getComputedStyle(projetosGrid).gap) || 24;
          return card ? card.offsetWidth + gap : 344;
        };

        navPrev.addEventListener('click', () => {
          projetosGrid.scrollBy({ left: -getScrollAmount(), behavior: 'smooth' });
        });

        navNext.addEventListener('click', () => {
          projetosGrid.scrollBy({ left: getScrollAmount(), behavior: 'smooth' });
        });
      }
    }
  }

  // ==========================================
  // SCROLL SUAVE
  // ==========================================

  initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
      anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const target = document.querySelector(this.getAttribute('href'));

        if (target) {
          // Offset especial para seção de projetos
          let headerOffset = 0;
          if (this.getAttribute('href') === '#projetos') {
            headerOffset = -150;
          }

          const elementPosition = target.getBoundingClientRect().top;
          const offsetPosition = elementPosition + window.pageYOffset - headerOffset;

          window.scrollTo({
            top: offsetPosition,
            behavior: 'smooth'
          });

          // Fechar menu mobile se aberto
          const navList = document.querySelector('.nav-list');
          const menuToggle = document.querySelector('.menu-toggle');
          if (navList.classList.contains('active')) {
            navList.classList.remove('active');
            menuToggle.setAttribute('aria-expanded', 'false');
            document.body.style.overflow = '';
          }
        }
      });
    });
  }

  // ==========================================
  // HEADER SCROLL EFFECT
  // ==========================================

  initHeaderScroll() {
    const header = document.querySelector('.site-header');
    let lastScroll = 0;
    let scrollDirection = 'up';

    window.addEventListener('scroll', () => {
      const currentScroll = window.pageYOffset;

      // Determinar direção do scroll
      if (currentScroll > lastScroll && currentScroll > 100) {
        scrollDirection = 'down';
      } else {
        scrollDirection = 'up';
      }

      // Adicionar classe scrolled quando scroll > 100
      if (currentScroll > 100) {
        header.classList.add('scrolled');

        // Esconder header quando scroll para baixo
        if (scrollDirection === 'down') {
          header.style.transform = 'translateY(-100%)';
        } else {
          header.style.transform = 'translateY(0)';
        }
      } else {
        header.classList.remove('scrolled');
        header.style.transform = 'translateY(0)';
      }

      lastScroll = currentScroll;
    });
  }

  // ==========================================
  // UTILITÁRIOS
  // ==========================================

  animateNumber(element, start, end) {
    const duration = 500;
    const startTime = performance.now();

    const update = (currentTime) => {
      const elapsed = currentTime - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const easeProgress = 1 - Math.pow(1 - progress, 3); // easeOutCubic

      const current = Math.floor(start + (end - start) * easeProgress);
      element.textContent = current;

      if (progress < 1) {
        requestAnimationFrame(update);
      }
    };

    requestAnimationFrame(update);
  }
}

// ==========================================
// INICIALIZAÇÃO
// ==========================================

document.addEventListener('DOMContentLoaded', () => {
  new LabInterface();

  // Animação inicial do Hero
  setTimeout(() => {
    document.querySelectorAll('.hero [data-animate]').forEach((el, index) => {
      setTimeout(() => {
        el.classList.add('animate');
      }, index * 100);
    });
  }, 300);
});

// ==========================================
// PREFERS REDUCED MOTION (Acessibilidade)
// ==========================================

if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
  document.documentElement.style.setProperty('--duration-normal', '0.01ms');
  document.documentElement.style.setProperty('--duration-slow', '0.01ms');
}